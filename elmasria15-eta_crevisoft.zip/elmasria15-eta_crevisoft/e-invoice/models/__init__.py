# -*- coding: utf-8 -*-

from . import res_company, res_partner, res_currency, account_move, tax_type_code, account_tax, product_template, uom, \
    taxpayer_activity_code
